import { config } from 'dotenv';
config();

import '@/ai/flows/weather-recommendation.ts';